import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Home from './components/Home';
import ProductList from './components/ProductList';
import ProductDetail from './components/ProductDetail';
import Cart from './components/Cart';
import Checkout from './components/Checkout';
import Orders from './components/Orders';
import Login from './components/Login';
import AdminDashboard from './components/AdminDashboard';
import SellerDashboard from './components/SellerDashboard';
import UserDashboard from './components/UserDashboard';
import NotificationsPage from './components/NotificationsPage';
import ChatRoomSelector from './components/ChatRoomSelector';
import Footer from './components/Footer';
import { CartProvider } from './context/CartContext';
import { UserProvider, useUser } from './context/UserContext';
import { WishlistProvider } from './context/WishlistContext';
import { ReviewsProvider } from './context/ReviewsContext';
import { NotificationsProvider } from './context/NotificationsContext';
import './App.css';

const Chat = lazy(() => import('./components/Chat'));

function AppContent() {
  const { user } = useUser();
  
  return (
    <div className="App">
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/products/:category" element={<ProductList />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/notifications" element={<NotificationsPage />} />
          <Route path="/chat" element={<ChatRoomSelector />} />
          <Route 
            path="/chat/:roomId" 
            element={
              <Suspense fallback={<div className="loading">Loading chat...</div>}>
                <Chat />
              </Suspense>
            } 
          />
          <Route path="/login" element={<Login />} />
          <Route 
            path="/admin/*" 
            element={user && user.role === 'admin' ? <AdminDashboard /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/seller/*" 
            element={user && (user.role === 'seller' || user.role === 'admin') ? <SellerDashboard /> : <Navigate to="/login" />} 
          />
          <Route 
            path="/user/*" 
            element={user ? <UserDashboard /> : <Navigate to="/login" />} 
          />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <UserProvider>
      <CartProvider>
        <WishlistProvider>
          <ReviewsProvider>
            <NotificationsProvider>
              <Router>
                <AppContent />
              </Router>
            </NotificationsProvider>
          </ReviewsProvider>
        </WishlistProvider>
      </CartProvider>
    </UserProvider>
  );
}

export default App;