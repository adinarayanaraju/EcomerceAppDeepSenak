import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useUser } from '../context/UserContext';

const Cart = () => {
  const { cart, updateQuantity, removeFromCart, getCartTotal } = useCart();
  const { user } = useUser();
  
  if (cart.items.length === 0) {
    return (
      <div className="container">
        <div className="card text-center p-2">
          <h2>Your Cart is Empty</h2>
          <p>Add items to your cart to see them here</p>
          <Link to="/" className="btn">Continue Shopping</Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container">
      <h2>Shopping Cart</h2>
      <div className="grid" style={{gridTemplateColumns: '2fr 1fr'}}>
        <div className="cart-items">
          {cart.items.map(item => (
            <div key={item.id} className="card flex-between mb-1 p-1">
              <div className="flex" style={{gap: '15px'}}>
                <img src={item.image} alt={item.name} style={{width: '100px', height: '100px', objectFit: 'contain'}} />
                <div>
                  <h3>{item.name}</h3>
                  <div className="price">${item.price}</div>
                  {item.freeShipping && <div>FREE Shipping</div>}
                </div>
              </div>
              
              <div>
                <select 
                  value={item.quantity} 
                  onChange={(e) => updateQuantity(item.id, parseInt(e.target.value))}
                >
                  {[...Array(10).keys()].map(num => (
                    <option key={num + 1} value={num + 1}>{num + 1}</option>
                  ))}
                </select>
                
                <button 
                  onClick={() => removeFromCart(item.id)}
                  style={{color: '#007185', border: 'none', background: 'none', cursor: 'pointer'}}
                >
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>
        
        <div className="cart-summary card p-2">
          <h3>Order Summary</h3>
          <div className="flex-between mb-1">
            <span>Subtotal ({cart.items.reduce((total, item) => total + item.quantity, 0)} items):</span>
            <span className="price">${getCartTotal().toFixed(2)}</span>
          </div>
          
          {user ? (
            <Link to="/checkout" className="btn btn-primary btn-block">
              Proceed to Checkout
            </Link>
          ) : (
            <Link to="/login" className="btn btn-primary btn-block">
              Sign in to checkout
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default Cart;