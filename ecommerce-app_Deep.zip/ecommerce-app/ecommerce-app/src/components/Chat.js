import React, { useState, useRef, useEffect, useCallback, useReducer } from 'react';
import { useUser } from '../context/UserContext';
import { useNotifications } from '../context/NotificationsContext';

// Custom hook for WebSocket connection
const useWebSocket = (url) => {
  const [socket, setSocket] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);

  useEffect(() => {
    const ws = new WebSocket(url);
    
    ws.onopen = () => {
      console.log('WebSocket connected');
      setIsConnected(true);
      setReconnectAttempts(0);
      setSocket(ws);
    };
    
    ws.onclose = () => {
      console.log('WebSocket disconnected');
      setIsConnected(false);
      setSocket(null);
      
      // Attempt reconnect with exponential backoff
      const timeout = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000);
      setTimeout(() => {
        setReconnectAttempts(prev => prev + 1);
      }, timeout);
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
    
    return () => {
      ws.close();
    };
  }, [url, reconnectAttempts]);

  return { socket, isConnected };
};

// Reducer for chat state management
const chatReducer = (state, action) => {
  switch (action.type) {
    case 'SET_MESSAGES':
      return { ...state, messages: action.payload };
    
    case 'ADD_MESSAGE':
      return { ...state, messages: [...state.messages, action.payload] };
    
    case 'SET_TYPING':
      return { ...state, typingUsers: action.payload };
    
    case 'ADD_TYPING_USER':
      if (state.typingUsers.includes(action.payload)) {
        return state;
      }
      return { ...state, typingUsers: [...state.typingUsers, action.payload] };
    
    case 'REMOVE_TYPING_USER':
      return { 
        ...state, 
        typingUsers: state.typingUsers.filter(user => user !== action.payload) 
      };
    
    case 'SET_CONNECTION_STATUS':
      return { ...state, isConnected: action.payload };
    
    default:
      return state;
  }
};

const Chat = ({ roomId = 'general' }) => {
  const { user } = useUser();
  const { addNotification } = useNotifications();
  const [message, setMessage] = useState('');
  const messagesEndRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  
  // Using useReducer for complex state management
  const [state, dispatch] = useReducer(chatReducer, {
    messages: [],
    typingUsers: [],
    isConnected: false
  });
  
  const { socket, isConnected } = useWebSocket('ws://localhost:3001');
  
  // Update connection status in state
  useEffect(() => {
    dispatch({ type: 'SET_CONNECTION_STATUS', payload: isConnected });
  }, [isConnected]);
  
  // Scroll to bottom when messages change
  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, []);
  
  useEffect(() => {
    scrollToBottom();
  }, [state.messages, scrollToBottom]);
  
  // Handle incoming WebSocket messages
  useEffect(() => {
    if (!socket) return;
    
    const handleMessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        switch (data.type) {
          case 'chat_history':
            dispatch({ type: 'SET_MESSAGES', payload: data.messages });
            break;
          
          case 'new_message':
            dispatch({ type: 'ADD_MESSAGE', payload: data.message });
            
            // Send notification if message is from another user
            if (data.message.sender !== user.name) {
              addNotification({
                type: 'chat',
                title: `New message from ${data.message.sender}`,
                message: data.message.text,
                link: `/chat/${roomId}`,
                image: 'https://via.placeholder.com/50x50?text=💬'
              });
            }
            break;
          
          case 'typing_start':
            dispatch({ type: 'ADD_TYPING_USER', payload: data.sender });
            break;
          
          case 'typing_end':
            dispatch({ type: 'REMOVE_TYPING_USER', payload: data.sender });
            break;
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    socket.addEventListener('message', handleMessage);
    
    return () => {
      socket.removeEventListener('message', handleMessage);
    };
  }, [socket, user, roomId, addNotification]);
  
  // Join room when socket is connected
  useEffect(() => {
    if (socket && isConnected) {
      socket.send(JSON.stringify({
        type: 'join_room',
        roomId,
        user: user.name
      }));
    }
  }, [socket, isConnected, roomId, user]);
  
  // Send message
  const sendMessage = useCallback(() => {
    if (message.trim() && socket) {
      socket.send(JSON.stringify({
        type: 'chat_message',
        text: message.trim(),
        sender: user.name,
        roomId
      }));
      setMessage('');
      
      // Send typing end event
      socket.send(JSON.stringify({
        type: 'typing_end',
        sender: user.name
      }));
    }
  }, [message, socket, user, roomId]);
  
  // Handle typing indicators
  const handleTyping = useCallback(() => {
    if (socket) {
      // Send typing start event
      socket.send(JSON.stringify({
        type: 'typing_start',
        sender: user.name
      }));
      
      // Clear previous timeout
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
      }
      
      // Set timeout to send typing end event
      typingTimeoutRef.current = setTimeout(() => {
        if (socket) {
          socket.send(JSON.stringify({
            type: 'typing_end',
            sender: user.name
          }));
        }
      }, 1000);
    }
  }, [socket, user]);
  
  // Handle key press
  const handleKeyPress = useCallback((e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }, [sendMessage]);
  
  // Format message time
  const formatTime = useCallback((timestamp) => {
    return new Date(timestamp).toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  }, []);
  
  return (
    <div className="chat-container">
      <div className="chat-header">
        <h2>Chat Room: {roomId}</h2>
        <div className="connection-status">
          <span className={`status-indicator ${state.isConnected ? 'connected' : 'disconnected'}`}>
            {state.isConnected ? '🟢 Connected' : '🔴 Disconnected'}
          </span>
        </div>
      </div>
      
      <div className="messages-container">
        {state.messages.length === 0 ? (
          <div className="empty-chat">
            <p>No messages yet. Start the conversation!</p>
          </div>
        ) : (
          state.messages.map(msg => (
            <div 
              key={msg.id} 
              className={`message ${msg.sender === user.name ? 'own-message' : 'other-message'}`}
            >
              <div className="message-content">
                <div className="message-sender">{msg.sender}</div>
                <div className="message-text">{msg.text}</div>
                <div className="message-time">{formatTime(msg.timestamp)}</div>
              </div>
            </div>
          ))
        )}
        
        {state.typingUsers.length > 0 && (
          <div className="typing-indicator">
            {state.typingUsers.join(', ')} {state.typingUsers.length === 1 ? 'is' : 'are'} typing...
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      <div className="message-input-container">
        <textarea
          value={message}
          onChange={(e) => {
            setMessage(e.target.value);
            handleTyping();
          }}
          onKeyPress={handleKeyPress}
          placeholder="Type a message..."
          disabled={!state.isConnected}
          rows={1}
          className="message-input"
        />
        <button 
          onClick={sendMessage} 
          disabled={!message.trim() || !state.isConnected}
          className="send-button"
        >
          Send
        </button>
      </div>
    </div>
  );
};

export default Chat;