import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const ChatRoomSelector = () => {
  const [roomId, setRoomId] = useState('');
  const navigate = useNavigate();

  const handleJoinRoom = (e) => {
    e.preventDefault();
    if (roomId.trim()) {
      navigate(`/chat/${roomId.trim()}`);
    }
  };

  const joinDefaultRoom = (room) => {
    navigate(`/chat/${room}`);
  };

  return (
    <div className="chat-room-selector">
      <h2>Join a Chat Room</h2>
      
      <div className="default-rooms">
        <h3>Quick Join:</h3>
        <div className="room-buttons">
          <button onClick={() => joinDefaultRoom('general')} className="room-btn">
            General
          </button>
          <button onClick={() => joinDefaultRoom('support')} className="room-btn">
            Customer Support
          </button>
          <button onClick={() => joinDefaultRoom('orders')} className="room-btn">
            Orders Help
          </button>
          <button onClick={() => joinDefaultRoom('tech')} className="room-btn">
            Technical Support
          </button>
        </div>
      </div>
      
      <div className="custom-room">
        <h3>Or create your own room:</h3>
        <form onSubmit={handleJoinRoom} className="room-form">
          <input
            type="text"
            value={roomId}
            onChange={(e) => setRoomId(e.target.value)}
            placeholder="Enter room name"
            className="room-input"
          />
          <button type="submit" disabled={!roomId.trim()} className="join-btn">
            Join Room
          </button>
        </form>
      </div>
    </div>
  );
};

export default ChatRoomSelector;