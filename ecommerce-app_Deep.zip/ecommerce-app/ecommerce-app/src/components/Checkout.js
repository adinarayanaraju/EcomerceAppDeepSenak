import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useUser } from '../context/UserContext';
import CheckoutSteps from './CheckoutSteps';

const Checkout = () => {
  const { cart, getCartTotal, clearCart } = useCart();
  const { user } = useUser();
  const [shippingInfo, setShippingInfo] = useState({
    address: '',
    city: '',
    state: '',
    zip: ''
  });
  const [paymentMethod, setPaymentMethod] = useState('credit_card');
  const [orderPlaced, setOrderPlaced] = useState(false);
  
  const handleSubmit = (e) => {
    e.preventDefault();
    // In a real app, you would process the order here
    console.log('Order placed:', { shippingInfo, paymentMethod, items: cart.items });
    clearCart();
    setOrderPlaced(true);
  };
  
  if (!user) {
    return (
      <div className="container">
        <div className="card text-center p-2">
          <h2>Please sign in to checkout</h2>
        </div>
      </div>
    );
  }
  
  if (orderPlaced) {
    return (
      <div className="container">
        <div className="card text-center p-2">
          <h2>Order Placed Successfully!</h2>
          <p>Thank you for your order. Your order number is #123456.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container">
      <CheckoutSteps />
      <h2>Checkout</h2>
      <form onSubmit={handleSubmit}>
        <div className="grid" style={{gridTemplateColumns: '2fr 1fr'}}>
          <div className="checkout-form">
            <div className="card p-2 mb-1">
              <h3>Shipping Address</h3>
              <div className="form-group">
                <label>Address:</label>
                <input 
                  type="text" 
                  value={shippingInfo.address} 
                  onChange={(e) => setShippingInfo({...shippingInfo, address: e.target.value})}
                  required 
                />
              </div>
              
              <div className="form-group">
                <label>City:</label>
                <input 
                  type="text" 
                  value={shippingInfo.city} 
                  onChange={(e) => setShippingInfo({...shippingInfo, city: e.target.value})}
                  required 
                />
              </div>
              
              <div className="form-group">
                <label>State:</label>
                <input 
                  type="text" 
                  value={shippingInfo.state} 
                  onChange={(e) => setShippingInfo({...shippingInfo, state: e.target.value})}
                  required 
                />
              </div>
              
              <div className="form-group">
                <label>ZIP Code:</label>
                <input 
                  type="text" 
                  value={shippingInfo.zip} 
                  onChange={(e) => setShippingInfo({...shippingInfo, zip: e.target.value})}
                  required 
                />
              </div>
            </div>
            
            <div className="card p-2">
              <h3>Payment Method</h3>
              <div className="form-group">
                <label>
                  <input 
                    type="radio" 
                    value="credit_card" 
                    checked={paymentMethod === 'credit_card'} 
                    onChange={() => setPaymentMethod('credit_card')}
                  />
                  Credit Card
                </label>
              </div>
              
              <div className="form-group">
                <label>
                  <input 
                    type="radio" 
                    value="paypal" 
                    checked={paymentMethod === 'paypal'} 
                    onChange={() => setPaymentMethod('paypal')}
                  />
                  PayPal
                </label>
              </div>
              
              <div className="form-group">
                <label>
                  <input 
                    type="radio" 
                    value="cash_on_delivery" 
                    checked={paymentMethod === 'cash_on_delivery'} 
                    onChange={() => setPaymentMethod('cash_on_delivery')}
                  />
                  Cash on Delivery
                </label>
              </div>
            </div>
          </div>
          
          <div className="order-summary card p-2">
            <h3>Order Summary</h3>
            <div className="flex-between mb-1">
              <span>Items ({cart.items.reduce((total, item) => total + item.quantity, 0)}):</span>
              <span>${getCartTotal().toFixed(2)}</span>
            </div>
            
            <div className="flex-between mb-1">
              <span>Shipping:</span>
              <span>$0.00</span>
            </div>
            
            <div className="flex-between mb-1">
              <span>Tax:</span>
              <span>${(getCartTotal() * 0.08).toFixed(2)}</span>
            </div>
            
            <hr />
            
            <div className="flex-between mb-1">
              <strong>Order Total:</strong>
              <strong className="price">${(getCartTotal() * 1.08).toFixed(2)}</strong>
            </div>
            
            <button type="submit" className="btn btn-primary btn-block">
              Place Your Order
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default Checkout;