import React, { useState } from 'react';

const CheckoutSteps = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const steps = [
    { id: 1, title: 'Shipping' },
    { id: 2, title: 'Payment' },
    { id: 3, title: 'Place Order' }
  ];

  return (
    <div className="checkout-steps">
      {steps.map(step => (
        <div 
          key={step.id} 
          className={`step ${step.id === currentStep ? 'active' : ''} ${step.id < currentStep ? 'completed' : ''}`}
        >
          <div className="step-number">{step.id}</div>
          <div className="step-title">{step.title}</div>
        </div>
      ))}
    </div>
  );
};

export default CheckoutSteps;