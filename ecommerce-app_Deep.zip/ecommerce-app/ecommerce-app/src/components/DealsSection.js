import React from 'react';
import { products } from '../data/staticData';
import ProductCard from './ProductCard';

const DealsSection = () => {
  const deals = products
    .filter(product => product.originalPrice)
    .sort((a, b) => {
      const discountA = (a.originalPrice - a.price) / a.originalPrice;
      const discountB = (b.originalPrice - b.price) / b.originalPrice;
      return discountB - discountA;
    })
    .slice(0, 8);

  if (deals.length === 0) return null;

  return (
    <div className="deals-section">
      <div className="section-header">
        <h2>Today's Deals</h2>
        <a href="/deals" className="see-all">See all deals</a>
      </div>
      
      <div className="deals-grid">
        {deals.map(product => {
          const discount = Math.round((1 - product.price / product.originalPrice) * 100);
          return (
            <div key={product.id} className="deal-item">
              <div className="deal-badge">Save {discount}%</div>
              <ProductCard product={product} />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default DealsSection;