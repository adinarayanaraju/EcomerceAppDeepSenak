import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="grid grid-4">
          <div>
            <h3>Get to Know Us</h3>
            <ul>
              <li>Careers</li>
              <li>Blog</li>
              <li>About Us</li>
              <li>Investor Relations</li>
            </ul>
          </div>
          
          <div>
            <h3>Make Money with Us</h3>
            <ul>
              <li>Sell products</li>
              <li>Sell on Our Site</li>
              <li>Become an Affiliate</li>
            </ul>
          </div>
          
          <div>
            <h3>Customer Service</h3>
            <ul>
              <li>Help</li>
              <li>Shipping Information</li>
              <li>Returns & Refunds</li>
              <li>Contact Us</li>
            </ul>
          </div>
          
          <div>
            <h3>Legal</h3>
            <ul>
              <li>Terms of Service</li>
              <li>Privacy Policy</li>
              <li>Cookie Policy</li>
              <li>GDPR</li>
            </ul>
          </div>
        </div>
        
        <div className="text-center p-1">
          <p>© 2023 E-Commerce App. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;