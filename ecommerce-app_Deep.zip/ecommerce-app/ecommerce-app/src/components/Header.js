import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useUser } from '../context/UserContext';
import NotificationBell from './NotificationBell';
import NotificationsPanel from './NotificationsPanel';

const Header = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const { getCartItemsCount } = useCart();
  const { user } = useUser();

  const handleSearch = (e) => {
    e.preventDefault();
    // Search functionality would be implemented here
    console.log('Search for:', searchQuery);
  };

  return (
    <header className="header">
      <div className="container">
        <div className="flex-between p-1">
          <Link to="/" className="logo">
            <h2>E-Commerce</h2>
          </Link>
          
          <form onSubmit={handleSearch} className="search-form">
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button type="submit">Search</button>
          </form>
          
          <div className="header-actions">
            <Link to={user ? "/notifications" : "/login"} className="header-link">
              <NotificationBell />
            </Link>
            
            <Link to={user ? "/orders" : "/login"} className="header-link">
              <div>
                <span>Hello, {user ? user.name : 'Guest'}</span>
                <br />
                <strong>{user ? 'Orders' : 'Sign In'}</strong>
              </div>
            </Link>
            
            <Link to="/cart" className="header-link">
              <div>
                <span className="cart-count">{getCartItemsCount()}</span>
                <br />
                <strong>Cart</strong>
              </div>
            </Link>
          </div>
        </div>
        
        <nav className="nav">
          <Link to="/products/electronics">Electronics</Link>
          <Link to="/products/fashion">Fashion</Link>
          <Link to="/products/home">Home & Kitchen</Link>
          <Link to="/products/books">Books</Link>
          <Link to="/products/toys">Toys & Games</Link>
          <Link to="/chat">Chat</Link>
        </nav>
      </div>
      <NotificationsPanel />
    </header>
  );
};

export default Header;