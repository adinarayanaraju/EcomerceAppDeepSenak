import React from 'react';
import { Link } from 'react-router-dom';
import ProductCard from './ProductCard';
import DealsSection from './DealsSection';
import { products } from '../data/staticData';

const Home = () => {
  const featuredProducts = products.filter(product => product.featured).slice(0, 8);
  
  return (
    <div className="container">
      <div className="hero-banner mb-2">
        <img src="https://via.placeholder.com/1500x300" alt="Hero Banner" style={{width: '100%'}} />
      </div>
      
      <DealsSection />
      
      <h2>Featured Products</h2>
      <div className="grid grid-4 mb-2">
        {featuredProducts.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
      
      <div className="categories mb-2">
        <h2>Shop by Category</h2>
        <div className="grid grid-4">
          <Link to="/products/electronics" className="card text-center">
            <h3>Electronics</h3>
            <p>Smartphones, Laptops, TVs and more</p>
          </Link>
          <Link to="/products/fashion" className="card text-center">
            <h3>Fashion</h3>
            <p>Clothing, Shoes, Accessories</p>
          </Link>
          <Link to="/products/home" className="card text-center">
            <h3>Home & Kitchen</h3>
            <p>Furniture, Appliances, Decor</p>
          </Link>
          <Link to="/products/books" className="card text-center">
            <h3>Books</h3>
            <p>Bestsellers, Novels, Textbooks</p>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;