import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import { useNavigate, useLocation } from 'react-router-dom';

const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [error, setError] = useState('');
  
  const { login, register } = useUser();
  const navigate = useNavigate();
  const location = useLocation();
  
  const from = location.state?.from?.pathname || '/';

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    
    if (isLogin) {
      const result = login(formData.email, formData.password);
      if (result.success) {
        navigate(from, { replace: true });
      } else {
        setError(result.message);
      }
    } else {
      if (formData.password !== formData.confirmPassword) {
        setError('Passwords do not match');
        return;
      }
      
      const result = register({
        name: formData.name,
        email: formData.email,
        password: formData.password
      });
      
      if (result.success) {
        navigate(from, { replace: true });
      }
    }
  };
  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };
  
  const demoLogin = (role) => {
    let email, password;
    
    switch(role) {
      case 'admin':
        email = 'admin@example.com';
        password = 'admin123';
        break;
      case 'seller':
        email = 'seller@example.com';
        password = 'seller123';
        break;
      case 'user':
        email = 'user@example.com';
        password = 'user123';
        break;
      default:
        return;
    }
    
    const result = login(email, password);
    if (result.success) {
      navigate(from, { replace: true });
    }
  };

  return (
    <div className="container">
      <div className="login-container">
        <div className="card">
          <h2 className="text-center">{isLogin ? 'Sign In' : 'Create Account'}</h2>
          
          {error && <div className="error-message">{error}</div>}
          
          <form onSubmit={handleSubmit} className="login-form">
            {!isLogin && (
              <div className="form-group">
                <label>Your Name</label>
                <input 
                  type="text" 
                  name="name" 
                  value={formData.name} 
                  onChange={handleChange}
                  required={!isLogin}
                />
              </div>
            )}
            
            <div className="form-group">
              <label>Email</label>
              <input 
                type="email" 
                name="email" 
                value={formData.email} 
                onChange={handleChange}
                required 
              />
            </div>
            
            <div className="form-group">
              <label>Password</label>
              <input 
                type="password" 
                name="password" 
                value={formData.password} 
                onChange={handleChange}
                required 
              />
            </div>
            
            {!isLogin && (
              <div className="form-group">
                <label>Confirm Password</label>
                <input 
                  type="password" 
                  name="confirmPassword" 
                  value={formData.confirmPassword} 
                  onChange={handleChange}
                  required={!isLogin}
                />
              </div>
            )}
            
            <button type="submit" className="btn btn-primary btn-block">
              {isLogin ? 'Sign In' : 'Create Account'}
            </button>
          </form>
          
          <div className="login-divider">
            <span>Or</span>
          </div>
          
          <div className="demo-logins">
            <h3>Demo Logins:</h3>
            <div className="demo-buttons">
              <button 
                className="btn demo-btn admin-demo" 
                onClick={() => demoLogin('admin')}
              >
                Login as Admin
              </button>
              <button 
                className="btn demo-btn seller-demo" 
                onClick={() => demoLogin('seller')}
              >
                Login as Seller
              </button>
              <button 
                className="btn demo-btn user-demo" 
                onClick={() => demoLogin('user')}
              >
                Login as User
              </button>
            </div>
          </div>
          
          <div className="text-center login-switch">
            <p>
              {isLogin ? 'New to our platform? ' : 'Already have an account? '}
              <button 
                type="button"
                onClick={() => setIsLogin(!isLogin)}
                className="link-button"
              >
                {isLogin ? 'Create an account' : 'Sign in'}
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;