import React from 'react';
import { useNotifications } from '../context/NotificationsContext';

const NotificationBell = () => {
  const { unreadCount, togglePanel, panelOpen } = useNotifications();

  return (
    <div className="notifications-icon-container">
      <button
        className="notifications-icon"
        onClick={() => togglePanel(!panelOpen)}
        aria-label="Notifications"
      >
        <span className="bell-icon">🔔</span>
        {unreadCount > 0 && (
          <span className="notification-badge">{unreadCount}</span>
        )}
      </button>
    </div>
  );
};

export default NotificationBell;