import React from 'react';
import { useNotifications } from '../context/NotificationsContext';
import { useNavigate } from 'react-router-dom';

const NotificationsPage = () => {
  const {
    notifications,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearAll
  } = useNotifications();

  const navigate = useNavigate();

  const formatDate = (timestamp) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const groupNotificationsByDate = () => {
    const groups = {};
    notifications.forEach(notification => {
      const date = new Date(notification.timestamp).toLocaleDateString();
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(notification);
    });
    return groups;
  };

  const groupedNotifications = groupNotificationsByDate();

  return (
    <div className="container">
      <div className="notifications-page">
        <div className="page-header">
          <h1>Notifications</h1>
          <div className="page-actions">
            {notifications.length > 0 && (
              <>
                {notifications.some(n => !n.read) && (
                  <button 
                    className="btn btn-secondary"
                    onClick={markAllAsRead}
                  >
                    Mark all as read
                  </button>
                )}
                <button 
                    className="btn btn-danger"
                    onClick={clearAll}
                  >
                    Clear all
                  </button>
              </>
            )}
          </div>
        </div>

        {notifications.length === 0 ? (
          <div className="empty-state">
            <div className="empty-state-icon">🔔</div>
            <h2>No notifications yet</h2>
            <p>Your notifications will appear here</p>
            <button 
              className="btn btn-primary"
              onClick={() => navigate('/')}
            >
              Continue Shopping
            </button>
          </div>
        ) : (
          <div className="notifications-timeline">
            {Object.entries(groupedNotifications).map(([date, dateNotifications]) => (
              <div key={date} className="notification-group">
                <h3 className="group-date">{date}</h3>
                {dateNotifications.map(notification => (
                  <div
                    key={notification.id}
                    className={`notification-card ${notification.read ? '' : 'unread'}`}
                  >
                    <div className="notification-image">
                      <img src={notification.image} alt={notification.title} />
                    </div>
                    <div className="notification-content">
                      <h4>{notification.title}</h4>
                      <p>{notification.message}</p>
                      <span className="notification-time">
                        {formatDate(notification.timestamp)}
                      </span>
                    </div>
                    <div className="notification-actions">
                      {!notification.read && (
                        <button
                          className="btn btn-sm"
                          onClick={() => markAsRead(notification.id)}
                        >
                          Mark as read
                        </button>
                      )}
                      <button
                        className="btn btn-sm btn-danger"
                        onClick={() => deleteNotification(notification.id)}
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default NotificationsPage;