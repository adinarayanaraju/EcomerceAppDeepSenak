import React, { useRef, useEffect } from 'react';
import { useNotifications } from '../context/NotificationsContext';
import { useNavigate } from 'react-router-dom';

const NotificationsPanel = () => {
  const {
    notifications,
    unreadCount,
    panelOpen,
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearAll,
    togglePanel
  } = useNotifications();

  const navigate = useNavigate();
  const panelRef = useRef(null);

  // Close panel when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (panelRef.current && !panelRef.current.contains(event.target)) {
        // Check if the click is not on the notification bell icon
        if (!event.target.closest('.notifications-icon')) {
          togglePanel(false);
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [togglePanel]);

  const handleNotificationClick = (notification) => {
    markAsRead(notification.id);
    navigate(notification.link);
    togglePanel(false);
  };

  const formatTime = (timestamp) => {
    const now = new Date();
    const notificationTime = new Date(timestamp);
    const diffInMinutes = Math.floor((now - notificationTime) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes} min ago`;
    } else if (diffInMinutes < 1440) {
      return `${Math.floor(diffInMinutes / 60)} hours ago`;
    } else {
      return `${Math.floor(diffInMinutes / 1440)} days ago`;
    }
  };

  if (!panelOpen) return null;

  return (
    <div className="notifications-panel" ref={panelRef}>
      <div className="notifications-header">
        <h3>Notifications</h3>
        <div className="notifications-actions">
          {unreadCount > 0 && (
            <button 
              className="mark-all-read"
              onClick={markAllAsRead}
            >
              Mark all as read
            </button>
          )}
          {notifications.length > 0 && (
            <button 
              className="clear-all"
              onClick={clearAll}
            >
              Clear all
            </button>
          )}
        </div>
      </div>

      <div className="notifications-list">
        {notifications.length === 0 ? (
          <div className="empty-notifications">
            <div className="empty-icon">🔔</div>
            <p>No notifications yet</p>
            <span>We'll notify you when something arrives</span>
          </div>
        ) : (
          notifications.map(notification => (
            <div
              key={notification.id}
              className={`notification-item ${notification.read ? '' : 'unread'}`}
              onClick={() => handleNotificationClick(notification)}
            >
              <div className="notification-image">
                <img src={notification.image} alt={notification.title} />
              </div>
              <div className="notification-content">
                <h4>{notification.title}</h4>
                <p>{notification.message}</p>
                <span className="notification-time">
                  {formatTime(notification.timestamp)}
                </span>
              </div>
              <div className="notification-actions">
                {!notification.read && (
                  <span className="unread-dot"></span>
                )}
                <button
                  className="delete-notification"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteNotification(notification.id);
                  }}
                  title="Delete notification"
                >
                  ×
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {notifications.length > 0 && (
        <div className="notifications-footer">
          <button 
            className="view-all-notifications"
            onClick={() => {
              navigate('/notifications');
              togglePanel(false);
            }}
          >
            View all notifications
          </button>
        </div>
      )}
    </div>
  );
};

export default NotificationsPanel;