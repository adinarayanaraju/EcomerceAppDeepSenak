import React from 'react';
import { useUser } from '../context/UserContext';
import { orders } from '../data/staticData';

const Orders = () => {
  const { user } = useUser();
  
  if (!user) {
    return (
      <div className="container">
        <div className="card text-center p-2">
          <h2>Please sign in to view your orders</h2>
        </div>
      </div>
    );
  }
  
  const userOrders = orders.filter(order => order.userId === user.id);
  
  return (
    <div className="container">
      <h2>Your Orders</h2>
      
      {userOrders.length === 0 ? (
        <div className="card text-center p-2">
          <p>You haven't placed any orders yet.</p>
          <a href="/" className="btn btn-primary">Start Shopping</a>
        </div>
      ) : (
        <div className="orders-list">
          {userOrders.map(order => (
            <div key={order.id} className="card order-card mb-1">
              <div className="order-header flex-between">
                <div>
                  <strong>Order Placed:</strong> {order.date}
                </div>
                <div>
                  <strong>Total:</strong> ${order.total.toFixed(2)}
                </div>
                <div>
                  <strong>Order #:</strong> {order.id}
                </div>
                <div>
                  <span className={`status-badge ${order.status}`}>
                    {order.status}
                  </span>
                </div>
              </div>
              
              <div className="order-items">
                {order.items.map((item, index) => (
                  <div key={index} className="order-item flex">
                    <div className="order-item-image">
                      <img src={item.image} alt={item.name} />
                    </div>
                    <div className="order-item-details">
                      <h4>{item.name}</h4>
                      <p>Quantity: {item.quantity}</p>
                      <p className="price">${item.price.toFixed(2)}</p>
                    </div>
                    <div className="order-item-actions">
                      <button className="btn-sm">Buy Again</button>
                      <button className="btn-sm">View Product</button>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="order-actions">
                <button className="btn">Track Package</button>
                <button className="btn">Return Items</button>
                <button className="btn">Leave Feedback</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Orders;