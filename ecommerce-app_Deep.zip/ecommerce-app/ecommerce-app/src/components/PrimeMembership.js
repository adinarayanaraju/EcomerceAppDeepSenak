import React from 'react';

const PrimeMembership = () => {
  return (
    <div className="prime-membership card">
      <div className="prime-header">
        <div className="prime-logo">PRIME</div>
        <h2>Try Amazon Prime</h2>
      </div>
      
      <div className="prime-benefits">
        <div className="benefit">
          <span className="benefit-icon">🚚</span>
          <div className="benefit-text">
            <h4>FREE Two-Day Shipping</h4>
            <p>On eligible items</p>
          </div>
        </div>
        
        <div className="benefit">
          <span className="benefit-icon">🎬</span>
          <div className="benefit-text">
            <h4>Prime Video</h4>
            <p>Thousands of movies and TV shows</p>
          </div>
        </div>
        
        <div className="benefit">
          <span className="benefit-icon">🎵</span>
          <div className="benefit-text">
            <h4>Prime Music</h4>
            <p>Over 2 million songs ad-free</p>
          </div>
        </div>
      </div>
      
      <div className="prime-action">
        <button className="btn btn-primary">Try Prime Free for 30 Days</button>
        <p className="prime-terms">$12.99/month after trial. Cancel anytime.</p>
      </div>
    </div>
  );
};

export default PrimeMembership;