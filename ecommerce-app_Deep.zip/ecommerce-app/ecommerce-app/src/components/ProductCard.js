import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';

const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  
  const inWishlist = isInWishlist(product.id);
  
  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
  };
  
  const handleWishlistToggle = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (inWishlist) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };
  
  return (
    <Link to={`/product/${product.id}`} className="card product-card">
      <div className="product-image-container">
        <img src={product.image} alt={product.name} style={{width: '100%', height: '200px', objectFit: 'contain'}} />
        <button 
          className="wishlist-btn"
          onClick={handleWishlistToggle}
          title={inWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          {inWishlist ? '❤️' : '🤍'}
        </button>
      </div>
      <h3>{product.name}</h3>
      <div className="rating">
        {'★'.repeat(Math.floor(product.rating))}
        {'☆'.repeat(5 - Math.floor(product.rating))}
        <span> ({product.reviews})</span>
      </div>
      <div className="price">
        {product.originalPrice && <span className="strike">${product.originalPrice}</span>}
        ${product.price}
      </div>
      {product.freeShipping && <div>FREE Shipping</div>}
      <button className="btn btn-block mt-1" onClick={handleAddToCart}>Add to Cart</button>
    </Link>
  );
};

export default ProductCard;