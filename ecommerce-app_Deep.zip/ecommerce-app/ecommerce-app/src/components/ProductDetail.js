import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { products } from '../data/staticData';
import ProductRecommendations from './ProductRecommendations';
import ProductReviews from './ProductReviews';
import PrimeMembership from './PrimeMembership';

const ProductDetail = () => {
  const { id } = useParams();
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  
  const product = products.find(p => p.id === parseInt(id));
  
  if (!product) {
    return <div className="container">Product not found</div>;
  }
  
  const inWishlist = isInWishlist(product.id);
  
  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product);
    }
  };
  
  const handleWishlistToggle = () => {
    if (inWishlist) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist(product);
    }
  };
  
  // Mock multiple images for the product
  const productImages = [
    product.image,
    'https://via.placeholder.com/500x500?text=Product+Angle',
    'https://via.placeholder.com/500x500?text=Product+Closeup',
    'https://via.placeholder.com/500x500?text=Product+In+Use'
  ];

  return (
    <div className="container">
      <div className="grid" style={{gridTemplateColumns: '1fr 2fr'}}>
        <div className="product-images">
          <div className="main-image">
            <img 
              src={productImages[selectedImage]} 
              alt={product.name} 
              style={{width: '100%'}} 
            />
          </div>
          <div className="thumbnail-images">
            {productImages.map((image, index) => (
              <img
                key={index}
                src={image}
                alt={`${product.name} view ${index + 1}`}
                className={selectedImage === index ? 'active' : ''}
                onClick={() => setSelectedImage(index)}
              />
            ))}
          </div>
        </div>
        
        <div className="product-info p-2">
          <h1>{product.name}</h1>
          <div className="product-actions">
            <button 
              className="wishlist-btn"
              onClick={handleWishlistToggle}
              title={inWishlist ? 'Remove from wishlist' : 'Add to wishlist'}
            >
              {inWishlist ? '❤️' : '🤍'}
            </button>
          </div>
          
          <div className="rating mb-1">
            {'★'.repeat(Math.floor(product.rating))}
            {'☆'.repeat(5 - Math.floor(product.rating))}
            <span> ({product.reviews} ratings)</span>
          </div>
          
          <hr />
          
          <div className="price mb-1">
            {product.originalPrice && <span className="strike">${product.originalPrice}</span>}
            <span style={{fontSize: '24px'}}>${product.price}</span>
            {product.originalPrice && (
              <span className="discount">
                {Math.round((1 - product.price / product.originalPrice) * 100)}% off
              </span>
            )}
          </div>
          
          <div className="mb-1">
            {product.freeShipping && (
              <div className="shipping-info">
                <span className="prime-badge">Prime</span>
                <strong>FREE delivery</strong> for Prime members
              </div>
            )}
            <div>In stock: {product.inStock ? 'Yes' : 'No'}</div>
          </div>
          
          <div className="mb-2">
            <label htmlFor="quantity">Quantity: </label>
            <select 
              id="quantity" 
              value={quantity} 
              onChange={(e) => setQuantity(parseInt(e.target.value))}
            >
              {[...Array(10).keys()].map(num => (
                <option key={num + 1} value={num + 1}>{num + 1}</option>
              ))}
            </select>
          </div>
          
          <div className="flex" style={{gap: '10px'}}>
            <button className="btn btn-primary" onClick={handleAddToCart}>
              Add to Cart
            </button>
            <button className="btn">Buy Now</button>
          </div>
          
          <div className="delivery-options">
            <h3>Delivery Options</h3>
            <div className="delivery-option">
              <input type="radio" id="standard" name="delivery" defaultChecked />
              <label htmlFor="standard">
                <strong>Standard Delivery</strong> - 3-5 business days
                <span>FREE</span>
              </label>
            </div>
            <div className="delivery-option">
              <input type="radio" id="express" name="delivery" />
              <label htmlFor="express">
                <strong>Express Delivery</strong> - 1-2 business days
                <span>$9.99</span>
              </label>
            </div>
          </div>
        </div>
      </div>
      
      <div className="product-description card mt-2">
        <h2>Product Description</h2>
        <p>{product.description}</p>
        
        <h3>Details</h3>
        <ul>
          {product.details && product.details.map((detail, index) => (
            <li key={index}>{detail}</li>
          ))}
        </ul>
      </div>
      
      <ProductReviews productId={product.id} />
      <PrimeMembership />
      <ProductRecommendations currentProductId={product.id} />
    </div>
  );
};

export default ProductDetail;