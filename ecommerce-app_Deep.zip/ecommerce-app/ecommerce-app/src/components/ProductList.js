import React from 'react';
import { useParams } from 'react-router-dom';
import ProductCard from './ProductCard';
import { products } from '../data/staticData';

const ProductList = () => {
  const { category } = useParams();
  const categoryProducts = products.filter(product => product.category === category);
  
  return (
    <div className="container">
      <h2>{category.charAt(0).toUpperCase() + category.slice(1)}</h2>
      <div className="grid grid-4">
        {categoryProducts.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default ProductList;