import React from 'react';
import { products } from '../data/staticData';
import ProductCard from './ProductCard';

const ProductRecommendations = ({ currentProductId, count = 4 }) => {
  // Filter out the current product and get random recommendations
  const recommendations = products
    .filter(product => product.id !== currentProductId)
    .sort(() => 0.5 - Math.random())
    .slice(0, count);

  if (recommendations.length === 0) return null;

  return (
    <div className="product-recommendations">
      <h2>Customers who viewed this item also viewed</h2>
      <div className="grid grid-4">
        {recommendations.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default ProductRecommendations;