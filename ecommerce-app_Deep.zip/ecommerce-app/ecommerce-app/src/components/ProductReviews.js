import React, { useState } from 'react';
import { useReviews } from '../context/ReviewsContext';
import { useUser } from '../context/UserContext';

const ProductReviews = ({ productId }) => {
  const { user } = useUser();
  const { getProductReviews, addReview, deleteReview } = useReviews();
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [review, setReview] = useState({
    rating: 5,
    title: '',
    comment: ''
  });

  const reviews = getProductReviews(productId);

  const handleSubmitReview = (e) => {
    e.preventDefault();
    if (!user) {
      alert('Please login to submit a review');
      return;
    }

    addReview(productId, {
      ...review,
      userName: user.name,
      userId: user.id
    });

    setReview({ rating: 5, title: '', comment: '' });
    setShowReviewForm(false);
  };

  const handleDeleteReview = (reviewId) => {
    if (window.confirm('Are you sure you want to delete this review?')) {
      deleteReview(productId, reviewId);
    }
  };

  return (
    <div className="product-reviews">
      <h2>Customer Reviews</h2>
      
      <div className="reviews-summary">
        <div className="average-rating">
          <span className="rating-large">
            {'★'.repeat(5)}
            <span className="rating-overlay" style={{ width: `${100 - (review.rating / 5) * 100}%` }}>
              {'☆'.repeat(5)}
            </span>
          </span>
          <span className="rating-text">{reviews.length} reviews</span>
        </div>
        
        <button 
          className="btn btn-primary"
          onClick={() => setShowReviewForm(!showReviewForm)}
        >
          Write a Review
        </button>
      </div>

      {showReviewForm && (
        <div className="review-form card">
          <h3>Write a Product Review</h3>
          <form onSubmit={handleSubmitReview}>
            <div className="form-group">
              <label>Rating</label>
              <div className="star-rating">
                {[1, 2, 3, 4, 5].map(star => (
                  <span
                    key={star}
                    className={star <= review.rating ? 'star filled' : 'star'}
                    onClick={() => setReview({ ...review, rating: star })}
                  >
                    {star <= review.rating ? '★' : '☆'}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="form-group">
              <label>Review Title</label>
              <input
                type="text"
                value={review.title}
                onChange={(e) => setReview({ ...review, title: e.target.value })}
                required
              />
            </div>
            
            <div className="form-group">
              <label>Your Review</label>
              <textarea
                value={review.comment}
                onChange={(e) => setReview({ ...review, comment: e.target.value })}
                rows="4"
                required
              ></textarea>
            </div>
            
            <div className="form-actions">
              <button type="submit" className="btn btn-primary">Submit Review</button>
              <button 
                type="button" 
                className="btn"
                onClick={() => setShowReviewForm(false)}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="reviews-list">
        {reviews.length === 0 ? (
          <p>No reviews yet. Be the first to review this product!</p>
        ) : (
          reviews.map(review => (
            <div key={review.id} className="review card">
              <div className="review-header">
                <div className="reviewer-info">
                  <span className="reviewer-name">{review.userName}</span>
                  <span className="review-date">
                    {new Date(review.date).toLocaleDateString()}
                  </span>
                </div>
                <div className="review-rating">
                  {'★'.repeat(review.rating)}{'☆'.repeat(5 - review.rating)}
                </div>
              </div>
              
              <h4 className="review-title">{review.title}</h4>
              <p className="review-comment">{review.comment}</p>
              
              {user && user.id === review.userId && (
                <div className="review-actions">
                  <button 
                    className="btn-sm btn-danger"
                    onClick={() => handleDeleteReview(review.id)}
                  >
                    Delete
                  </button>
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default ProductReviews;