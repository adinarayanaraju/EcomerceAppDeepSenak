import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { products } from '../data/staticData';
import ProductCard from './ProductCard';

const RecentlyViewed = () => {
  const [viewedProducts, setViewedProducts] = useState([]);
  const location = useLocation();

  useEffect(() => {
    // Check if current path is a product page
    if (location.pathname.startsWith('/product/')) {
      const productId = parseInt(location.pathname.split('/')[2]);
      const product = products.find(p => p.id === productId);
      
      if (product) {
        // Add to recently viewed, avoiding duplicates
        setViewedProducts(prev => {
          const filtered = prev.filter(p => p.id !== productId);
          return [product, ...filtered].slice(0, 4);
        });
      }
    }
  }, [location]);

  if (viewedProducts.length === 0) return null;

  return (
    <div className="recently-viewed">
      <h2>Recently Viewed</h2>
      <div className="grid grid-4">
        {viewedProducts.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
};

export default RecentlyViewed;