import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import { products, orders } from '../data/staticData';

const SellerDashboard = () => {
  const { user } = useUser();
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // Filter products and orders for this seller
  const sellerProducts = products.filter(p => p.sellerId === user.id);
  const sellerOrders = orders.filter(o => 
    o.items.some(item => sellerProducts.some(p => p.id === item.productId))
  );
  
  // Stats for dashboard
  const stats = {
    totalProducts: sellerProducts.length,
    totalOrders: sellerOrders.length,
    totalRevenue: sellerOrders.reduce((sum, order) => {
      const sellerItems = order.items.filter(item => 
        sellerProducts.some(p => p.id === item.productId)
      );
      return sum + sellerItems.reduce((itemSum, item) => itemSum + item.price * item.quantity, 0);
    }, 0),
    pendingOrders: sellerOrders.filter(o => o.status === 'pending').length
  };

  return (
    <div className="container">
      <h1>Seller Dashboard</h1>
      <p>Welcome, {user.name}! Manage your products and orders here.</p>
      
      <div className="dashboard-tabs">
        <button 
          className={activeTab === 'dashboard' ? 'active' : ''} 
          onClick={() => setActiveTab('dashboard')}
        >
          Dashboard
        </button>
        <button 
          className={activeTab === 'products' ? 'active' : ''} 
          onClick={() => setActiveTab('products')}
        >
          Products
        </button>
        <button 
          className={activeTab === 'orders' ? 'active' : ''} 
          onClick={() => setActiveTab('orders')}
        >
          Orders
        </button>
        <button 
          className={activeTab === 'analytics' ? 'active' : ''} 
          onClick={() => setActiveTab('analytics')}
        >
          Analytics
        </button>
      </div>
      
      <div className="dashboard-content">
        {activeTab === 'dashboard' && (
          <div className="seller-dashboard">
            <h2>Overview</h2>
            <div className="stats-grid">
              <div className="stat-card">
                <h3>Total Products</h3>
                <p>{stats.totalProducts}</p>
              </div>
              <div className="stat-card">
                <h3>Total Orders</h3>
                <p>{stats.totalOrders}</p>
              </div>
              <div className="stat-card">
                <h3>Total Revenue</h3>
                <p>${stats.totalRevenue.toFixed(2)}</p>
              </div>
              <div className="stat-card">
                <h3>Pending Orders</h3>
                <p>{stats.pendingOrders}</p>
              </div>
            </div>
            
            <h2>Recent Orders</h2>
            <div className="card">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {sellerOrders.slice(0, 5).map(order => (
                    <tr key={order.id}>
                      <td>#{order.id}</td>
                      <td>{order.userName}</td>
                      <td>{order.date}</td>
                      <td>${order.total.toFixed(2)}</td>
                      <td>
                        <span className={`status-badge ${order.status}`}>
                          {order.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {activeTab === 'products' && (
          <div className="seller-products">
            <div className="flex-between mb-2">
              <h2>Product Management</h2>
              <button className="btn btn-primary">Add New Product</button>
            </div>
            <div className="card">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sellerProducts.map(product => (
                    <tr key={product.id}>
                      <td>{product.id}</td>
                      <td>{product.name}</td>
                      <td>{product.category}</td>
                      <td>${product.price.toFixed(2)}</td>
                      <td>{product.inStock ? 'In Stock' : 'Out of Stock'}</td>
                      <td>
                        <button className="btn-sm">Edit</button>
                        <button className="btn-sm btn-danger">Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {activeTab === 'orders' && (
          <div className="seller-orders">
            <h2>Order Management</h2>
            <div className="card">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Date</th>
                    <th>Items</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sellerOrders.map(order => (
                    <tr key={order.id}>
                      <td>#{order.id}</td>
                      <td>{order.userName}</td>
                      <td>{order.date}</td>
                      <td>{order.items.length} items</td>
                      <td>${order.total.toFixed(2)}</td>
                      <td>
                        <select defaultValue={order.status}>
                          <option value="pending">Pending</option>
                          <option value="processing">Processing</option>
                          <option value="shipped">Shipped</option>
                          <option value="delivered">Delivered</option>
                          <option value="cancelled">Cancelled</option>
                        </select>
                      </td>
                      <td>
                        <button className="btn-sm">View</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {activeTab === 'analytics' && (
          <div className="seller-analytics">
            <h2>Sales Analytics</h2>
            <div className="card">
              <h3>Sales Overview</h3>
              <p>This section would contain charts and graphs showing sales performance over time.</p>
              
              <div className="analytics-grid">
                <div className="analytics-card">
                  <h4>Top Selling Products</h4>
                  <ul>
                    {sellerProducts.slice(0, 5).map(product => (
                      <li key={product.id}>
                        <span>{product.name}</span>
                        <span>15 sales</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="analytics-card">
                  <h4>Revenue by Category</h4>
                  <ul>
                    <li>
                      <span>Electronics</span>
                      <span>$1,250.00</span>
                    </li>
                    <li>
                      <span>Fashion</span>
                      <span>$850.00</span>
                    </li>
                    <li>
                      <span>Home & Kitchen</span>
                      <span>$620.00</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SellerDashboard;