import React, { useState } from 'react';
import { useUser } from '../context/UserContext';
import { orders } from '../data/staticData';

const UserDashboard = () => {
  const { user, updateProfile } = useUser();
  const [activeTab, setActiveTab] = useState('profile');
  const [editMode, setEditMode] = useState(false);
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email,
    address: '123 Main St, City, State 12345',
    phone: '(555) 123-4567'
  });
  
  const userOrders = orders.filter(order => order.userId === user.id);

  const handleSaveProfile = (e) => {
    e.preventDefault();
    updateProfile(formData);
    setEditMode(false);
  };

  return (
    <div className="container">
      <h1>My Account</h1>
      <p>Welcome, {user.name}! Manage your account and orders here.</p>
      
      <div className="dashboard-tabs">
        <button 
          className={activeTab === 'profile' ? 'active' : ''} 
          onClick={() => setActiveTab('profile')}
        >
          Profile
        </button>
        <button 
          className={activeTab === 'orders' ? 'active' : ''} 
          onClick={() => setActiveTab('orders')}
        >
          Orders
        </button>
        <button 
          className={activeTab === 'addresses' ? 'active' : ''} 
          onClick={() => setActiveTab('addresses')}
        >
          Addresses
        </button>
        <button 
          className={activeTab === 'wishlist' ? 'active' : ''} 
          onClick={() => setActiveTab('wishlist')}
        >
          Wishlist
        </button>
      </div>
      
      <div className="dashboard-content">
        {activeTab === 'profile' && (
          <div className="user-profile">
            <div className="flex-between mb-2">
              <h2>Personal Information</h2>
              {!editMode && (
                <button className="btn" onClick={() => setEditMode(true)}>
                  Edit Profile
                </button>
              )}
            </div>
            
            <div className="card">
              {editMode ? (
                <form onSubmit={handleSaveProfile}>
                  <div className="form-group">
                    <label>Full Name</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Email Address</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      required
                    />
                  </div>
                  
                  <div className="form-group">
                    <label>Phone Number</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>
                  
                  <div className="flex" style={{gap: '10px'}}>
                    <button type="submit" className="btn btn-primary">
                      Save Changes
                    </button>
                    <button 
                      type="button" 
                      className="btn"
                      onClick={() => setEditMode(false)}
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                <div className="profile-info">
                  <p><strong>Name:</strong> {user.name}</p>
                  <p><strong>Email:</strong> {user.email}</p>
                  <p><strong>Phone:</strong> {formData.phone}</p>
                </div>
              )}
            </div>
          </div>
        )}
        
        {activeTab === 'orders' && (
          <div className="user-orders">
            <h2>Order History</h2>
            
            {userOrders.length === 0 ? (
              <div className="card text-center p-2">
                <p>You haven't placed any orders yet.</p>
                <a href="/" className="btn btn-primary">Start Shopping</a>
              </div>
            ) : (
              <div className="orders-list">
                {userOrders.map(order => (
                  <div key={order.id} className="card order-card mb-1">
                    <div className="order-header flex-between">
                      <div>
                        <strong>Order Placed:</strong> {order.date}
                      </div>
                      <div>
                        <strong>Total:</strong> ${order.total.toFixed(2)}
                      </div>
                      <div>
                        <strong>Order #:</strong> {order.id}
                      </div>
                      <div>
                        <span className={`status-badge ${order.status}`}>
                          {order.status}
                        </span>
                      </div>
                    </div>
                    
                    <div className="order-items">
                      {order.items.map((item, index) => (
                        <div key={index} className="order-item flex">
                          <div className="order-item-image">
                            <img src={item.image} alt={item.name} />
                          </div>
                          <div className="order-item-details">
                            <h4>{item.name}</h4>
                            <p>Quantity: {item.quantity}</p>
                            <p className="price">${item.price.toFixed(2)}</p>
                          </div>
                          <div className="order-item-actions">
                            <button className="btn-sm">Buy Again</button>
                            <button className="btn-sm">View Product</button>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="order-actions">
                      <button className="btn">Track Package</button>
                      <button className="btn">Return Items</button>
                      <button className="btn">Leave Feedback</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'addresses' && (
          <div className="user-addresses">
            <div className="flex-between mb-2">
              <h2>Saved Addresses</h2>
              <button className="btn btn-primary">Add New Address</button>
            </div>
            
            <div className="card">
              <div className="address-list">
                <div className="address-card">
                  <h4>Default Address</h4>
                  <p>{formData.address}</p>
                  <p>{formData.phone}</p>
                  
                  <div className="address-actions">
                    <button className="btn-sm">Edit</button>
                    <button className="btn-sm">Set as Default</button>
                    <button className="btn-sm btn-danger">Remove</button>
                  </div>
                </div>
                
                <div className="address-card">
                  <h4>Work Address</h4>
                  <p>456 Office Blvd, Business Park, State 12345</p>
                  <p>(555) 987-6543</p>
                  
                  <div className="address-actions">
                    <button className="btn-sm">Edit</button>
                    <button className="btn-sm">Set as Default</button>
                    <button className="btn-sm btn-danger">Remove</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'wishlist' && (
          <div className="user-wishlist">
            <h2>Your Wishlist</h2>
            
            <div className="card">
              <p>You haven't added any items to your wishlist yet.</p>
              <a href="/" className="btn btn-primary">Start Shopping</a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserDashboard;