import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { useUser } from './UserContext';

const NotificationsContext = createContext();

// Different types of notifications
const NOTIFICATION_TYPES = {
  ORDER: 'order',
  PROMOTION: 'promotion',
  PRICE_DROP: 'price_drop',
  WISHLIST: 'wishlist',
  REVIEW: 'review',
  SYSTEM: 'system',
  CHAT: 'chat'
};

// Generate sample notifications
const generateSampleNotifications = (userId) => {
  return [
    {
      id: 1,
      userId: userId,
      type: NOTIFICATION_TYPES.ORDER,
      title: 'Order Shipped',
      message: 'Your order #12345 has been shipped and is on the way.',
      link: '/orders/12345',
      read: false,
      timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 minutes ago
      image: 'https://via.placeholder.com/50x50?text=📦'
    },
    {
      id: 2,
      userId: userId,
      type: NOTIFICATION_TYPES.PRICE_DROP,
      title: 'Price Drop Alert',
      message: 'Wireless Headphones price dropped from $129.99 to $99.99',
      link: '/product/1',
      read: false,
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
      image: 'https://via.placeholder.com/50x50?text=📉'
    },
    {
      id: 3,
      userId: userId,
      type: NOTIFICATION_TYPES.PROMOTION,
      title: 'Special Offer',
      message: 'Get 20% off on all electronics this weekend!',
      link: '/products/electronics',
      read: true,
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5).toISOString(), // 5 hours ago
      image: 'https://via.placeholder.com/50x50?text=🎁'
    },
    {
      id: 4,
      userId: userId,
      type: NOTIFICATION_TYPES.WISHLIST,
      title: 'Wishlist Item Back in Stock',
      message: 'Smart Watch is back in stock. Hurry before it sells out!',
      link: '/product/4',
      read: true,
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
      image: 'https://via.placeholder.com/50x50?text=⭐'
    },
    {
      id: 5,
      userId: userId,
      type: NOTIFICATION_TYPES.REVIEW,
      title: 'Review Your Purchase',
      message: 'How do you like your Wireless Headphones? Share your experience.',
      link: '/product/1/review',
      read: true,
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(), // 2 days ago
      image: 'https://via.placeholder.com/50x50?text=✏️'
    },
    {
      id: 6,
      userId: userId,
      type: NOTIFICATION_TYPES.SYSTEM,
      title: 'Security Alert',
      message: 'New login from a new device. Was this you?',
      link: '/account/security',
      read: true,
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(), // 3 days ago
      image: 'https://via.placeholder.com/50x50?text=🔒'
    }
  ];
};

const notificationsReducer = (state, action) => {
  switch (action.type) {
    case 'LOAD_NOTIFICATIONS':
      return {
        ...state,
        notifications: action.payload,
        unreadCount: action.payload.filter(n => !n.read).length
      };
    
    case 'ADD_NOTIFICATION':
      const newNotification = {
        ...action.payload,
        id: Date.now(),
        timestamp: new Date().toISOString(),
        read: false
      };
      const updatedNotifications = [newNotification, ...state.notifications];
      return {
        ...state,
        notifications: updatedNotifications,
        unreadCount: state.unreadCount + 1
      };
    
    case 'MARK_AS_READ':
      const markedNotifications = state.notifications.map(notification =>
        notification.id === action.payload 
          ? { ...notification, read: true } 
          : notification
      );
      return {
        ...state,
        notifications: markedNotifications,
        unreadCount: markedNotifications.filter(n => !n.read).length
      };
    
    case 'MARK_ALL_AS_READ':
      const allReadNotifications = state.notifications.map(notification => ({
        ...notification,
        read: true
      }));
      return {
        ...state,
        notifications: allReadNotifications,
        unreadCount: 0
      };
    
    case 'DELETE_NOTIFICATION':
      const filteredNotifications = state.notifications.filter(
        notification => notification.id !== action.payload
      );
      const deletedNotification = state.notifications.find(
        notification => notification.id === action.payload
      );
      return {
        ...state,
        notifications: filteredNotifications,
        unreadCount: deletedNotification && !deletedNotification.read 
          ? state.unreadCount - 1 
          : state.unreadCount
      };
    
    case 'CLEAR_ALL':
      return {
        ...state,
        notifications: [],
        unreadCount: 0
      };
    
    case 'TOGGLE_PANEL':
      return {
        ...state,
        panelOpen: action.payload
      };
    
    default:
      return state;
  }
};

export const NotificationsProvider = ({ children }) => {
  const [state, dispatch] = useReducer(notificationsReducer, {
    notifications: [],
    unreadCount: 0,
    panelOpen: false
  });

  const { user } = useUser();

  // Load notifications when user changes
  useEffect(() => {
    if (user) {
      const userNotifications = generateSampleNotifications(user.id);
      dispatch({ type: 'LOAD_NOTIFICATIONS', payload: userNotifications });
    } else {
      dispatch({ type: 'LOAD_NOTIFICATIONS', payload: [] });
    }
  }, [user]);

  const addNotification = (notification) => {
    dispatch({ type: 'ADD_NOTIFICATION', payload: notification });
  };

  const markAsRead = (notificationId) => {
    dispatch({ type: 'MARK_AS_READ', payload: notificationId });
  };

  const markAllAsRead = () => {
    dispatch({ type: 'MARK_ALL_AS_READ' });
  };

  const deleteNotification = (notificationId) => {
    dispatch({ type: 'DELETE_NOTIFICATION', payload: notificationId });
  };

  const clearAll = () => {
    dispatch({ type: 'CLEAR_ALL' });
  };

  const togglePanel = (isOpen) => {
    dispatch({ type: 'TOGGLE_PANEL', payload: isOpen });
  };

  return (
    <NotificationsContext.Provider value={{
      notifications: state.notifications,
      unreadCount: state.unreadCount,
      panelOpen: state.panelOpen,
      addNotification,
      markAsRead,
      markAllAsRead,
      deleteNotification,
      clearAll,
      togglePanel,
      NOTIFICATION_TYPES
    }}>
      {children}
    </NotificationsContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationsContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationsProvider');
  }
  return context;
};