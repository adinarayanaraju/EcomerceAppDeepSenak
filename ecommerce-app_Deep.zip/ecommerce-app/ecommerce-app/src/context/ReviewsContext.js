// src/context/ReviewsContext.js
import React, { createContext, useContext, useReducer } from 'react';

const ReviewsContext = createContext();

const reviewsReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_REVIEW':
      return {
        ...state,
        [action.payload.productId]: [
          ...(state[action.payload.productId] || []),
          action.payload.review
        ]
      };
    
    case 'UPDATE_REVIEW':
      return {
        ...state,
        [action.payload.productId]: state[action.payload.productId].map(review => 
          review.id === action.payload.reviewId 
            ? { ...review, ...action.payload.updates } 
            : review
        )
      };
    
    case 'DELETE_REVIEW':
      return {
        ...state,
        [action.payload.productId]: state[action.payload.productId].filter(
          review => review.id !== action.payload.reviewId
        )
      };
    
    default:
      return state;
  }
};

export const ReviewsProvider = ({ children }) => {
  const [reviews, dispatch] = useReducer(reviewsReducer, {});

  const addReview = (productId, review) => {
    dispatch({ 
      type: 'ADD_REVIEW', 
      payload: { 
        productId, 
        review: {
          id: Date.now(),
          date: new Date().toISOString(),
          ...review
        }
      } 
    });
  };

  const updateReview = (productId, reviewId, updates) => {
    dispatch({ 
      type: 'UPDATE_REVIEW', 
      payload: { productId, reviewId, updates } 
    });
  };

  const deleteReview = (productId, reviewId) => {
    dispatch({ 
      type: 'DELETE_REVIEW', 
      payload: { productId, reviewId } 
    });
  };

  const getProductReviews = (productId) => {
    return reviews[productId] || [];
  };

  const getProductRating = (productId) => {
    const productReviews = getProductReviews(productId);
    if (productReviews.length === 0) return 0;
    
    const total = productReviews.reduce((sum, review) => sum + review.rating, 0);
    return total / productReviews.length;
  };

  return (
    <ReviewsContext.Provider value={{
      reviews,
      addReview,
      updateReview,
      deleteReview,
      getProductReviews,
      getProductRating
    }}>
      {children}
    </ReviewsContext.Provider>
  );
};

export const useReviews = () => {
  const context = useContext(ReviewsContext);
  if (!context) {
    throw new Error('useReviews must be used within a ReviewsProvider');
  }
  return context;
};