import React, { createContext, useContext, useState } from 'react';

const UserContext = createContext();

// Static user data
const staticUsers = [
  { id: 1, email: 'admin@example.com', password: 'admin123', name: 'Admin User', role: 'admin' },
  { id: 2, email: 'seller@example.com', password: 'seller123', name: 'Seller User', role: 'seller' },
  { id: 3, email: 'user@example.com', password: 'user123', name: 'Regular User', role: 'user' },
];

export const UserProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [users, setUsers] = useState(staticUsers);

  const login = (email, password) => {
    const foundUser = users.find(u => u.email === email && u.password === password);
    if (foundUser) {
      setUser(foundUser);
      return { success: true, user: foundUser };
    }
    return { success: false, message: 'Invalid credentials' };
  };

  const register = (userData) => {
    const newUser = {
      id: users.length + 1,
      ...userData,
      role: 'user' // Default role
    };
    setUsers([...users, newUser]);
    setUser(newUser);
    return { success: true, user: newUser };
  };

  const logout = () => {
    setUser(null);
  };

  const updateProfile = (updatedData) => {
    const updatedUsers = users.map(u => 
      u.id === user.id ? { ...u, ...updatedData } : u
    );
    setUsers(updatedUsers);
    setUser({ ...user, ...updatedData });
  };

  return (
    <UserContext.Provider value={{
      user,
      users,
      login,
      register,
      logout,
      updateProfile
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
};