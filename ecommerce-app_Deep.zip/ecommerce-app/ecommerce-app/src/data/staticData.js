// Products
export const products = [
    {
      id: 1,
      name: 'Wireless Bluetooth Headphones',
      price: 129.99,
      originalPrice: 149.99,
      category: 'electronics',
      image: 'https://via.placeholder.com/300x300?text=Headphones',
      rating: 4.5,
      reviews: 1245,
      freeShipping: true,
      featured: true,
      inStock: true,
      sellerId: 2,
      description: 'High-quality wireless headphones with noise cancellation and long battery life.',
      details: [
        'Active Noise Cancellation',
        '30-hour battery life',
        'Bluetooth 5.0',
        'Built-in microphone'
      ]
    },
    {
      id: 2,
      name: 'Smartphone 128GB',
      price: 699.99,
      category: 'electronics',
      image: 'https://via.placeholder.com/300x300?text=Smartphone',
      rating: 4.8,
      reviews: 2897,
      freeShipping: true,
      featured: true,
      inStock: true,
      sellerId: 2,
      description: 'Latest smartphone with high-resolution camera and powerful processor.',
      details: [
        '6.5-inch OLED display',
        'Triple camera system',
        '128GB storage',
        '5G capable'
      ]
    },
    {
      id: 3,
      name: 'Laptop 15.6"',
      price: 999.99,
      originalPrice: 1199.99,
      category: 'electronics',
      image: 'https://via.placeholder.com/300x300?text=Laptop',
      rating: 4.6,
      reviews: 1567,
      freeShipping: true,
      featured: true,
      inStock: true,
      sellerId: 2,
      description: 'Powerful laptop for work and entertainment with fast processor and ample storage.',
      details: [
        'Intel Core i7 processor',
        '16GB RAM',
        '512GB SSD',
        '15.6" Full HD display'
      ]
    },
    {
      id: 4,
      name: 'Smart Watch',
      price: 199.99,
      category: 'electronics',
      image: 'https://via.placeholder.com/300x300?text=Smart+Watch',
      rating: 4.3,
      reviews: 876,
      freeShipping: false,
      featured: true,
      inStock: true,
      sellerId: 2,
      description: 'Feature-rich smartwatch with health monitoring and notification support.',
      details: [
        'Heart rate monitor',
        'Water resistant',
        '7-day battery life',
        'Compatible with iOS and Android'
      ]
    },
    {
      id: 5,
      name: 'Men\'s Casual Shirt',
      price: 39.99,
      originalPrice: 49.99,
      category: 'fashion',
      image: 'https://via.placeholder.com/300x300?text=Shirt',
      rating: 4.2,
      reviews: 543,
      freeShipping: true,
      featured: false,
      inStock: true,
      sellerId: 2,
      description: 'Comfortable and stylish casual shirt for everyday wear.',
      details: [
        '100% cotton',
        'Machine washable',
        'Slim fit',
        'Available in multiple colors'
      ]
    },
    {
      id: 6,
      name: 'Women\'s Running Shoes',
      price: 89.99,
      category: 'fashion',
      image: 'https://via.placeholder.com/300x300?text=Running+Shoes',
      rating: 4.7,
      reviews: 932,
      freeShipping: true,
      featured: true,
      inStock: true,
      sellerId: 2,
      description: 'Lightweight and comfortable running shoes with excellent cushioning.',
      details: [
        'Breathable mesh upper',
        'Cushioned insole',
        'Rubber outsole',
        'Available in multiple sizes'
      ]
    },
    {
      id: 7,
      name: 'Coffee Maker',
      price: 79.99,
      category: 'home',
      image: 'https://via.placeholder.com/300x300?text=Coffee+Maker',
      rating: 4.4,
      reviews: 765,
      freeShipping: true,
      featured: false,
      inStock: true,
      sellerId: 2,
      description: 'Programmable coffee maker with automatic shutoff and brew pause.',
      details: [
        '12-cup capacity',
        'Programmable timer',
        'Pause and serve',
        'Auto shutoff'
      ]
    },
    {
      id: 8,
      name: 'Best Selling Novel',
      price: 14.99,
      originalPrice: 19.99,
      category: 'books',
      image: 'https://via.placeholder.com/300x300?text=Novel',
      rating: 4.9,
      reviews: 1243,
      freeShipping: false,
      featured: true,
      inStock: true,
      sellerId: 2,
      description: 'Award-winning novel that has captivated readers worldwide.',
      details: [
        'Paperback',
        '432 pages',
        'Published 2022',
        'Bestseller'
      ]
    },
    {
      id: 9,
      name: 'Building Blocks Set',
      price: 49.99,
      category: 'toys',
      image: 'https://via.placeholder.com/300x300?text=Building+Blocks',
      rating: 4.8,
      reviews: 432,
      freeShipping: true,
      featured: false,
      inStock: true,
      sellerId: 2,
      description: 'Educational building blocks set for creative play and learning.',
      details: [
        '250 pieces',
        'Multiple colors',
        'Storage container',
        'Ages 5+'
      ]
    },
    {
      id: 10,
      name: 'Wireless Earbuds',
      price: 79.99,
      category: 'electronics',
      image: 'https://via.placeholder.com/300x300?text=Earbuds',
      rating: 4.1,
      reviews: 321,
      freeShipping: true,
      featured: false,
      inStock: true,
      sellerId: 2,
      description: 'Compact wireless earbuds with charging case and long battery life.',
      details: [
        'Bluetooth 5.2',
        '24-hour battery with case',
        'IPX5 water resistant',
        'Touch controls'
      ]
    }
  ];
  
  // Categories
  export const categories = [
    { id: 1, name: 'electronics', description: 'Electronics and gadgets' },
    { id: 2, name: 'fashion', description: 'Clothing and accessories' },
    { id: 3, name: 'home', description: 'Home and kitchen appliances' },
    { id: 4, name: 'books', description: 'Books and magazines' },
    { id: 5, name: 'toys', description: 'Toys and games' }
  ];
  
  // Orders
  export const orders = [
    {
      id: '1001',
      userId: 3,
      userName: 'Regular User',
      date: 'May 15, 2023',
      items: [
        { productId: 1, name: 'Wireless Bluetooth Headphones', price: 129.99, quantity: 1, image: 'https://via.placeholder.com/300x300?text=Headphones' },
        { productId: 8, name: 'Best Selling Novel', price: 14.99, quantity: 2, image: 'https://via.placeholder.com/300x300?text=Novel' }
      ],
      total: 159.97,
      status: 'delivered'
    },
    {
      id: '1002',
      userId: 3,
      userName: 'Regular User',
      date: 'April 22, 2023',
      items: [
        { productId: 6, name: 'Women\'s Running Shoes', price: 89.99, quantity: 1, image: 'https://via.placeholder.com/300x300?text=Running+Shoes' }
      ],
      total: 89.99,
      status: 'shipped'
    },
    {
      id: '1003',
      userId: 1,
      userName: 'Admin User',
      date: 'June 5, 2023',
      items: [
        { productId: 3, name: 'Laptop 15.6"', price: 999.99, quantity: 1, image: 'https://via.placeholder.com/300x300?text=Laptop' },
        { productId: 4, name: 'Smart Watch', price: 199.99, quantity: 1, image: 'https://via.placeholder.com/300x300?text=Smart+Watch' }
      ],
      total: 1199.98,
      status: 'processing'
    },
    {
      id: '1004',
      userId: 2,
      userName: 'Seller User',
      date: 'June 10, 2023',
      items: [
        { productId: 5, name: 'Men\'s Casual Shirt', price: 39.99, quantity: 3, image: 'https://via.placeholder.com/300x300?text=Shirt' },
        { productId: 10, name: 'Wireless Earbuds', price: 79.99, quantity: 1, image: 'https://via.placeholder.com/300x300?text=Earbuds' }
      ],
      total: 199.96,
      status: 'pending'
    }
  ];
  
  // Users (additional to the ones in UserContext)
  export const users = [
    { id: 1, email: 'admin@example.com', password: 'admin123', name: 'Admin User', role: 'admin' },
    { id: 2, email: 'seller@example.com', password: 'seller123', name: 'Seller User', role: 'seller' },
    { id: 3, email: 'user@example.com', password: 'user123', name: 'Regular User', role: 'user' },
    { id: 4, email: 'john@example.com', password: 'password', name: 'John Doe', role: 'user' },
    { id: 5, email: 'jane@example.com', password: 'password', name: 'Jane Smith', role: 'user' }
  ];