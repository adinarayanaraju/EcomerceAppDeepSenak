const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// Serve static files for SSR
app.use(express.static(path.join(__dirname, '../build')));

// In-memory store for messages (in production, use a database)
const chatRooms = new Map();

// WebSocket connection handling
wss.on('connection', (ws) => {
  console.log('Client connected');
  
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      
      switch (data.type) {
        case 'join_room':
          if (!chatRooms.has(data.roomId)) {
            chatRooms.set(data.roomId, []);
          }
          ws.roomId = data.roomId;
          // Send chat history to the client
          ws.send(JSON.stringify({
            type: 'chat_history',
            messages: chatRooms.get(data.roomId)
          }));
          break;
          
        case 'chat_message':
          if (ws.roomId && chatRooms.has(ws.roomId)) {
            const newMessage = {
              id: Date.now(),
              text: data.text,
              sender: data.sender,
              timestamp: new Date().toISOString(),
              roomId: ws.roomId
            };
            
            // Add to room history
            chatRooms.get(ws.roomId).push(newMessage);
            
            // Broadcast to all clients in the same room
            wss.clients.forEach(client => {
              if (client.roomId === ws.roomId && client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify({
                  type: 'new_message',
                  message: newMessage
                }));
              }
            });
          }
          break;
          
        case 'typing_start':
        case 'typing_end':
          // Broadcast typing indicators to other clients in the room
          wss.clients.forEach(client => {
            if (client !== ws && client.roomId === ws.roomId && client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify(data));
            }
          });
          break;
      }
    } catch (error) {
      console.error('Error processing message:', error);
    }
  });
  
  ws.on('close', () => {
    console.log('Client disconnected');
  });
});

// SSR route for chat
app.get('/chat/:roomId?', (req, res) => {
  const roomId = req.params.roomId || 'general';
  const initialMessages = chatRooms.get(roomId) || [];
  
  // Basic SSR - in a real app, you'd use a proper templating engine or React SSR
  res.send(`
    <!DOCTYPE html>
    <html>
      <head>
        <title>Chat Room ${roomId}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
          body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
          .chat-container { max-width: 800px; margin: 0 auto; }
        </style>
      </head>
      <body>
        <div id="root">
          <div class="chat-container">
            <h1>Chat Room: ${roomId}</h1>
            <div id="messages">
              ${initialMessages.map(msg => `
                <div class="message">
                  <strong>${msg.sender}:</strong> ${msg.text}
                  <span class="time">${new Date(msg.timestamp).toLocaleTimeString()}</span>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
        <script src="/client.js"></script>
      </body>
    </html>
  `);
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});